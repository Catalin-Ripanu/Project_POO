 /**
 * O interfata ce cuprinde o metoda care intoarce caracterul de afisat in terminal sau GUI
 */
public interface CellElement {
    char toCharacter();
}
